package com.example.absa_eo_application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SoilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soil);
    }
}